-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 24, 2026 at 05:57 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `scholarship_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `scholarships`
--

CREATE TABLE `scholarships` (
  `id` int(11) NOT NULL,
  `csv_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `provider` varchar(255) NOT NULL,
  `min_cgpa` decimal(3,2) NOT NULL,
  `department` varchar(255) NOT NULL,
  `need_based` enum('yes','no') NOT NULL DEFAULT 'no',
  `gender` varchar(20) NOT NULL DEFAULT 'All',
  `amount_bdt` int(11) NOT NULL,
  `deadline` date NOT NULL,
  `description` text NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `scholarships`
--

INSERT INTO `scholarships` (`id`, `csv_id`, `name`, `provider`, `min_cgpa`, `department`, `need_based`, `gender`, `amount_bdt`, `deadline`, `description`, `created_at`) VALUES
(1, 1, 'Merit Excellence Award', 'Bayview University', 3.80, 'All', 'no', 'All', 30000, '2027-02-15', 'For students with outstanding CGPA. Renewable every semester if CGPA stays above 3.80.', '2026-11-24 14:51:35'),
(2, 2, 'Future Engineer Scholarship', 'Tech Foundation BD', 3.50, 'CSE;EEE;CE', 'no', 'All', 40000, '2027-03-10', 'For engineering students who show interest in research or projects.', '2026-11-24 14:51:35'),
(3, 3, 'Coders of Tomorrow Grant', 'Digital Bangladesh Trust', 3.20, 'CSE', 'no', 'All', 25000, '2027-02-28', 'For CSE students who have built at least one software project.', '2026-11-24 14:51:35'),
(4, 4, 'Need-Based Tuition Support', 'Bayview University', 2.50, 'All', 'yes', 'All', 20000, '2027-01-31', 'Partial tuition support for students from low-income families.', '2026-11-24 14:51:35'),
(5, 5, 'Women in Tech Scholarship', 'Women Leaders Network', 3.00, 'CSE;EEE', 'no', 'Female', 35000, '2027-03-20', 'For female students studying computer science or electrical engineering.', '2026-11-24 14:51:35'),
(6, 6, 'Business Leaders Award', 'Chattogram Business Forum', 3.40, 'BBA', 'no', 'All', 30000, '2027-04-05', 'For BBA students with leadership experience in clubs or events.', '2026-11-24 14:51:35'),
(7, 7, 'Literature and Language Prize', 'Language Society BD', 3.30, 'English', 'no', 'All', 20000, '2027-03-01', 'For English department students with strong writing or public speaking skills.', '2026-11-24 14:51:35'),
(8, 8, 'Green Infrastructure Grant', 'Civil Builders Association', 3.00, 'CE', 'no', 'All', 30000, '2027-04-15', 'For civil engineering students working on sustainable building ideas.', '2026-11-24 14:51:35'),
(9, 9, 'First Generation Learner Scholarship', 'Education for All Foundation', 2.80, 'All', 'yes', 'All', 25000, '2027-02-20', 'For students who are the first in their family to attend university.', '2026-11-24 14:51:35'),
(10, 10, 'Sports Excellence Scholarship', 'Bayview University', 2.50, 'All', 'no', 'All', 15000, '2027-03-25', 'For students who represented the university in sports competitions.', '2026-11-24 14:51:35'),
(11, 11, 'Rural Student Support Fund', 'Village Education Trust', 2.70, 'All', 'yes', 'All', 22000, '2027-05-01', 'For students from rural areas with financial need.', '2026-11-24 14:51:35'),
(12, 12, 'Power Systems Scholarship', 'National Energy Society', 3.50, 'EEE', 'no', 'All', 35000, '2027-03-30', 'For EEE students interested in power and renewable energy.', '2026-11-24 14:51:35'),
(13, 13, 'Startup Spark Award', 'Young Entrepreneurs Club', 3.00, 'BBA;CSE', 'no', 'All', 20000, '2027-04-20', 'For students with a startup idea or a small running business.', '2026-11-24 14:51:35'),
(14, 14, 'Community Volunteer Scholarship', 'Helping Hands BD', 2.60, 'All', 'no', 'All', 12000, '2027-05-10', 'For students with at least 100 hours of volunteer work in one year.', '2026-11-24 14:51:35'),
(15, 15, 'Top Rank Honors Scholarship', 'Bayview University', 3.90, 'All', 'no', 'All', 50000, '2027-01-25', 'For the top 5 students of each department by CGPA.', '2026-11-24 14:51:35'),
(16, 16, 'Emergency Hardship Fund', 'Bayview University', 2.00, 'All', 'yes', 'All', 18000, '2027-12-31', 'For students facing sudden financial difficulty. Applications are open all year.', '2026-11-24 14:51:35'),
(17, 17, 'Youth Voice Scholarship', 'Young Entrepreneurs Club', 3.00, 'All', 'yes', 'All', 19000, '2027-07-30', 'For students who speak up on youth and education issues.', '2026-11-24 14:51:35'),
(18, 18, 'Disability Inclusion Support', 'Teesta Education Society', 2.60, 'All', 'no', 'All', 30000, '2027-11-16', 'For students with a disability to support learning needs and study costs.', '2026-11-24 14:51:35'),
(19, 19, 'Embedded Systems Grant', 'Sundarban Youth Trust', 3.30, 'EEE', 'no', 'All', 32000, '2027-02-14', 'For EEE students who have worked on an electronics or power project.', '2026-11-24 14:51:35'),
(20, 20, 'Marketing Talent Award', 'Education for All Foundation', 3.50, 'BBA', 'no', 'All', 35000, '2027-08-11', 'For BBA students who have a small business or startup idea.', '2026-11-24 14:51:35'),
(21, 21, 'Student Journalist Award', 'National Energy Society', 3.00, 'All', 'no', 'All', 30000, '2027-09-07', 'For students who write for a campus magazine, newspaper or news page.', '2026-11-24 14:51:35'),
(22, 22, 'Girls Education Support Fund', 'Rupsha Industries Welfare Fund', 2.70, 'All', 'yes', 'Female', 23000, '2027-04-17', 'Helps female students continue studies despite financial problems.', '2026-11-24 14:51:35'),
(23, 23, 'Bright Future Need Grant', 'Sundarban Youth Trust', 2.80, 'All', 'yes', 'All', 28000, '2027-07-10', 'Helps with tuition fee and books for students with proven financial need.', '2026-11-24 14:51:35'),
(24, 24, 'Research Starter Scholarship', 'Padma Education Trust', 3.60, 'CSE;EEE', 'no', 'All', 39000, '2027-08-15', 'For CSE and EEE students who want to start research or join a lab.', '2026-11-24 14:51:35'),
(25, 25, 'Women in Engineering Award', 'Hilltop Alumni Network', 3.20, 'All', 'no', 'Female', 37000, '2027-10-17', 'Supports female students who want to build a career in their field.', '2026-11-24 14:51:35'),
(26, 26, 'Robotics Learners Award', 'Teesta Education Society', 3.70, 'EEE', 'no', 'All', 24000, '2027-04-22', 'For EEE students interested in renewable energy or embedded systems.', '2026-11-24 14:51:35'),
(27, 27, 'Debate Champions Scholarship', 'Coastal Bank Foundation', 2.80, 'All', 'no', 'All', 26000, '2027-06-03', 'For students who win or take part in debate competitions.', '2026-11-24 14:51:35'),
(28, 28, 'Web Developer Scholarship', 'Surma Learning Foundation', 3.00, 'CSE', 'no', 'All', 37000, '2027-04-26', 'Supports CSE students who want to learn modern software skills.', '2026-11-24 14:51:36'),
(29, 29, 'Books and Fees Support', 'Bright Minds Trust', 2.90, 'All', 'yes', 'All', 19000, '2027-10-09', 'Helps with tuition fee and books for students with proven financial need.', '2026-11-24 14:51:36'),
(30, 30, 'Girls in STEM Grant', 'Helping Hands BD', 2.90, 'All', 'no', 'Female', 36000, '2027-02-05', 'Supports female students who want to build a career in their field.', '2026-11-24 14:51:36'),
(31, 31, 'Safe Buildings Scholarship', 'Education for All Foundation', 2.90, 'CE', 'no', 'All', 37000, '2027-04-04', 'For CE students working on roads, bridges or water projects.', '2026-11-24 14:51:36'),
(32, 32, 'Entrepreneurship Scholarship', 'Civil Builders Association', 3.40, 'BBA', 'no', 'All', 19000, '2027-08-26', 'For BBA students with leadership experience in clubs or events.', '2026-11-24 14:51:36'),
(33, 33, 'National Business Scholarship', 'Sundarban Youth Trust', 3.10, 'BBA', 'no', 'All', 32000, '2027-08-15', 'For BBA students who have a small business or startup idea.', '2026-11-24 14:51:36'),
(34, 34, 'Chattogram Need-Based Support', 'Chattogram Business Forum', 2.90, 'All', 'yes', 'All', 21000, '2027-02-27', 'Partial support for students facing financial difficulty.', '2026-11-24 14:51:36'),
(35, 35, 'Bengal Need-Based Support', 'Hilltop Alumni Network', 2.50, 'All', 'yes', 'All', 20000, '2027-01-28', 'For students from low-income families who need help with tuition.', '2026-11-24 14:51:36'),
(36, 36, 'Teesta Coding Scholarship', 'Rupsha Industries Welfare Fund', 3.10, 'CSE', 'no', 'All', 21000, '2027-08-09', 'For CSE students with a public GitHub profile showing real project work.', '2026-11-24 14:51:36'),
(37, 37, 'Data Science Starter Grant', 'Coastal Bank Foundation', 3.40, 'CSE', 'no', 'All', 40000, '2027-11-27', 'For CSE students with a public GitHub profile showing real project work.', '2026-11-24 14:51:36'),
(38, 38, 'Rupsha Tech Entrepreneur Grant', 'Digital Bangladesh Trust', 3.60, 'BBA;CSE', 'no', 'All', 30000, '2027-02-04', 'For BBA and CSE students who want to build a tech startup.', '2026-11-24 14:51:36'),
(39, 39, 'Language Need-Based Support', 'Helping Hands BD', 2.90, 'All', 'yes', 'All', 30000, '2027-06-11', 'Helps with tuition fee and books for students with proven financial need.', '2026-11-24 14:51:36'),
(40, 40, 'Low-Income Student Award', 'Hilltop Alumni Network', 2.90, 'All', 'yes', 'All', 28000, '2027-11-16', 'For hardworking students who may leave studies because of money problems.', '2026-11-24 14:51:36'),
(41, 41, 'Banking Careers Award', 'Bengal Future Fund', 3.00, 'BBA', 'no', 'All', 23000, '2027-07-04', 'Supports BBA students who join business case competitions.', '2026-11-24 14:51:36'),
(42, 42, 'Bayview Electronics Scholarship', 'Meghna Scholars Society', 3.10, 'EEE', 'no', 'All', 22000, '2027-10-17', 'For EEE students who have worked on an electronics or power project.', '2026-11-24 14:51:36'),
(43, 43, 'Port Civil Engineering Grant', 'Chattogram Business Forum', 3.60, 'CE', 'no', 'All', 21000, '2027-07-23', 'For CE students who want to work on flood and cyclone resilient buildings.', '2026-11-24 14:51:36'),
(44, 44, 'National Women Leaders Scholarship', 'Hilltop Alumni Network', 3.40, 'All', 'no', 'Female', 33000, '2027-10-26', 'For female students with good academic results and leadership potential.', '2026-11-24 14:51:36'),
(45, 45, 'Shonar Writing Scholarship', 'Shonar Bangla Trust', 2.90, 'English', 'no', 'All', 27000, '2027-08-20', 'For English students with strong writing, poetry or story skills.', '2026-11-24 14:51:36'),
(46, 46, 'Bright Need-Based Support', 'Hilltop Alumni Network', 2.10, 'All', 'yes', 'All', 18000, '2027-12-01', 'Partial support for students facing financial difficulty.', '2026-11-24 14:51:36'),
(47, 47, 'Clean Campus Award', 'Bayview University', 3.20, 'All', 'no', 'All', 11000, '2027-09-26', 'For students who help keep the campus clean and organized.', '2026-11-24 14:51:36'),
(48, 48, 'Bright Business Scholarship', 'Bengal Future Fund', 3.50, 'BBA', 'no', 'All', 28000, '2027-08-26', 'For BBA students with leadership experience in clubs or events.', '2026-11-24 14:51:36'),
(49, 49, 'Young Engineering Merit Award', 'Shapla Foundation', 3.50, 'CSE;EEE;CE', 'no', 'All', 31000, '2027-09-04', 'For engineering students who want to continue with higher studies.', '2026-11-24 14:51:36'),
(50, 50, 'Water Resource Scholarship', 'Port City Rotary Friends', 3.40, 'CE', 'no', 'All', 37000, '2027-01-19', 'For civil engineering students interested in safe and low-cost housing.', '2026-11-24 14:51:36'),
(51, 51, 'Mobile App Maker Award', 'Karnaphuli Alumni Association', 3.20, 'CSE', 'no', 'All', 31000, '2027-07-15', 'For CSE students interested in artificial intelligence, data or web development.', '2026-11-24 14:51:36'),
(52, 52, 'Shonar STEM Scholarship', 'Green Delta Care Fund', 3.50, 'CSE;EEE', 'no', 'All', 40000, '2027-01-18', 'For students who won or joined a hackathon or science fair.', '2026-11-24 14:51:36'),
(53, 53, 'CGPA Champions Award', 'Surma Learning Foundation', 3.60, 'All', 'no', 'All', 15000, '2027-06-08', 'For students who improved their CGPA every semester.', '2026-11-24 14:51:36'),
(54, 54, 'Scholars of the Year', 'National Energy Society', 3.70, 'All', 'no', 'All', 50000, '2027-03-30', 'Rewards consistent academic performance.', '2026-11-24 14:51:36'),
(55, 55, 'AI Learners Grant', 'Hilltop Alumni Network', 3.30, 'CSE', 'no', 'All', 25000, '2027-09-08', 'Supports CSE students who want to learn modern software skills.', '2026-11-24 14:51:36'),
(56, 56, 'Disaster Resilience Scholarship', 'Bright Minds Trust', 3.60, 'CE', 'no', 'All', 20000, '2027-10-25', 'For CE students working on roads, bridges or water projects.', '2026-11-24 14:51:36'),
(57, 57, 'Port Need-Based Support', 'Coastal Bank Foundation', 2.20, 'All', 'yes', 'All', 20000, '2027-02-07', 'For students from low-income families who need help with tuition.', '2026-11-24 14:51:36'),
(58, 58, 'Community Service Award', 'Bright Minds Trust', 2.90, 'All', 'no', 'All', 29000, '2027-05-18', 'Recognizes students who lead service projects for their community.', '2026-11-24 14:51:36'),
(59, 59, 'Linguistics Learners Award', 'Shonar Bangla Trust', 3.50, 'English', 'no', 'All', 24000, '2027-09-30', 'For English students who take part in debate or public speaking.', '2026-11-24 14:51:36'),
(60, 60, 'Green Communication Scholarship', 'Bayview University', 3.20, 'BBA;English', 'no', 'All', 24000, '2027-07-26', 'For students who lead a student club or magazine.', '2026-11-24 14:51:36'),
(61, 61, 'Rural Students Fund', 'Shapla Foundation', 3.20, 'All', 'no', 'All', 21000, '2027-06-15', 'Supports students from rural areas who study away from home.', '2026-11-24 14:51:36'),
(62, 62, 'Cyber Safety Scholarship', 'Civil Builders Association', 3.50, 'CSE', 'no', 'All', 23000, '2027-03-03', 'Supports CSE students who want to learn modern software skills.', '2026-11-24 14:51:36'),
(63, 63, 'Student Leader Scholarship', 'Shapla Foundation', 2.30, 'All', 'no', 'All', 18000, '2027-03-19', 'For students who lead a student club or society.', '2026-11-24 14:51:36'),
(64, 64, 'Creative Writing Scholarship', 'Young Entrepreneurs Club', 3.10, 'English', 'no', 'All', 28000, '2027-12-07', 'For English students who take part in debate or public speaking.', '2026-11-24 14:51:36'),
(65, 65, 'Daughters of Bangladesh Scholarship', 'Bengal Future Fund', 3.50, 'All', 'no', 'Female', 21000, '2027-08-24', 'Supports female students who want to build a career in their field.', '2026-11-24 14:51:36'),
(66, 66, 'Future Engineers Grant', 'Coastal Bank Foundation', 3.30, 'CSE;EEE;CE', 'no', 'All', 37000, '2027-11-14', 'Supports engineering students who join technical competitions.', '2026-11-24 14:51:36'),
(67, 67, 'Engineering Excellence Scholarship', 'Shapla Foundation', 3.50, 'CSE;EEE;CE', 'no', 'All', 49000, '2027-08-18', 'For engineering students who want to continue with higher studies.', '2026-11-24 14:51:36'),
(68, 68, 'Renewable Energy Scholarship', 'Civil Builders Association', 3.50, 'EEE', 'no', 'All', 27000, '2027-05-30', 'For EEE students interested in renewable energy or embedded systems.', '2026-11-24 14:51:36'),
(69, 69, 'Smart Grid Scholarship', 'Surma Learning Foundation', 3.20, 'EEE', 'no', 'All', 21000, '2027-10-02', 'For EEE students who have worked on an electronics or power project.', '2026-11-24 14:51:36'),
(70, 70, 'Shapla STEM Scholarship', 'Padma Education Trust', 3.70, 'CSE;EEE', 'no', 'All', 37000, '2027-04-09', 'For students who won or joined a hackathon or science fair.', '2026-11-24 14:51:36'),
(71, 71, 'Helping Business Scholarship', 'Surma Learning Foundation', 3.50, 'BBA', 'no', 'All', 20000, '2027-05-15', 'For BBA students with strong results in accounting or finance courses.', '2026-11-24 14:51:36'),
(72, 72, 'Women in Business Award', 'Teesta Education Society', 3.30, 'All', 'no', 'Female', 20000, '2027-10-01', 'For female students from any department who show strong effort.', '2026-11-24 14:51:36'),
(73, 73, 'Innovation Lab Grant', 'Young Entrepreneurs Club', 3.40, 'CSE;EEE', 'no', 'All', 35000, '2027-10-18', 'For CSE and EEE students who want to start research or join a lab.', '2026-11-24 14:51:36'),
(74, 74, 'Leadership Voices Grant', 'Digital Bangladesh Trust', 3.40, 'BBA;English', 'no', 'All', 25000, '2027-05-19', 'For BBA and English students with strong communication skills.', '2026-11-24 14:51:36'),
(75, 75, 'Dean\'s Honor Scholarship', 'Tech Foundation BD', 3.50, 'All', 'no', 'All', 47000, '2027-11-13', 'Rewards consistent academic performance.', '2026-11-24 14:51:36'),
(76, 76, 'Circuit Makers Award', 'Green Delta Care Fund', 3.00, 'EEE', 'no', 'All', 30000, '2027-02-13', 'For EEE students who have worked on an electronics or power project.', '2026-11-24 14:51:36'),
(77, 77, 'Open Source Contributor Award', 'Young Entrepreneurs Club', 3.00, 'CSE', 'no', 'All', 43000, '2027-09-07', 'For CSE students who have built a software project or joined a programming contest.', '2026-11-24 14:51:36'),
(78, 78, 'Science and Technology Award', 'National Energy Society', 3.50, 'CSE;EEE', 'no', 'All', 29000, '2027-05-04', 'For CSE and EEE students who want to start research or join a lab.', '2026-11-24 14:51:36'),
(79, 79, 'Startup Founders Award', 'Education for All Foundation', 3.40, 'BBA;CSE', 'no', 'All', 23000, '2027-09-10', 'For students working on a small online business.', '2026-11-24 14:51:36'),
(80, 80, 'Blood Donor Society Grant', 'Coastal Bank Foundation', 2.50, 'All', 'no', 'All', 12000, '2027-07-10', 'For students who are regular volunteer blood donors.', '2026-11-24 14:51:36'),
(81, 81, 'Engineering Need Support Grant', 'Digital Bangladesh Trust', 3.00, 'CSE;EEE;CE', 'yes', 'All', 28000, '2027-06-29', 'For engineering students with financial need and good effort.', '2026-11-24 14:51:36'),
(82, 82, 'Bright Merit Scholarship', 'Digital Bangladesh Trust', 3.50, 'All', 'no', 'All', 33000, '2027-05-11', 'For students who improved their CGPA every semester.', '2026-11-24 14:51:36'),
(83, 83, 'Teesta Business Scholarship', 'Padma Education Trust', 3.50, 'BBA', 'no', 'All', 21000, '2027-06-17', 'For BBA students with strong results in accounting or finance courses.', '2026-11-24 14:51:36'),
(84, 84, 'National Electronics Scholarship', 'Karnaphuli Alumni Association', 3.40, 'EEE', 'no', 'All', 25000, '2027-08-27', 'Supports EEE students who join robotics or hardware competitions.', '2026-11-24 14:51:36'),
(85, 85, 'Padma Civil Engineering Grant', 'Shonar Bangla Trust', 3.00, 'CE', 'no', 'All', 28000, '2027-04-07', 'For CE students who want to work on flood and cyclone resilient buildings.', '2026-11-24 14:51:36'),
(86, 86, 'Algorithm Champions Award', 'Bayview University', 3.20, 'CSE', 'no', 'All', 42000, '2027-08-19', 'For CSE students with a public GitHub profile showing real project work.', '2026-11-24 14:51:36'),
(87, 87, 'Study Without Worry Fund', 'Hilltop Alumni Network', 2.30, 'All', 'yes', 'All', 22000, '2027-03-17', 'Partial support for students facing financial difficulty.', '2026-11-24 14:51:36'),
(88, 88, 'Teaching English Scholarship', 'Shapla Foundation', 3.50, 'English', 'no', 'All', 21000, '2027-05-19', 'For English students with strong writing, poetry or story skills.', '2026-11-24 14:51:36'),
(89, 89, 'Public Speaking Award', 'Surma Learning Foundation', 3.50, 'English', 'no', 'All', 15000, '2027-10-27', 'For English students with strong writing, poetry or story skills.', '2026-11-24 14:51:36'),
(90, 90, 'Tech Student Hardship Fund', 'Bayview University', 3.20, 'CSE;EEE;CE', 'yes', 'All', 33000, '2027-02-11', 'For engineering students with financial need and good effort.', '2026-11-24 14:51:36'),
(91, 91, 'Coastal Area Students Grant', 'Meghna Scholars Society', 3.30, 'All', 'yes', 'All', 10000, '2027-09-17', 'For students from coastal areas with difficult travel and study conditions.', '2026-11-24 14:51:36'),
(92, 92, 'Rising Star Scholarship', 'Shonar Bangla Trust', 3.70, 'All', 'no', 'All', 43000, '2027-02-10', 'For students with strong CGPA from any department.', '2026-11-24 14:51:36'),
(93, 93, 'Haor Region Students Fund', 'Bright Minds Trust', 2.60, 'All', 'yes', 'All', 30000, '2027-12-06', 'For students from haor (wetland) areas.', '2026-11-24 14:51:36'),
(94, 94, 'First Generation Learner Grant', 'Surma Learning Foundation', 2.90, 'All', 'no', 'All', 28000, '2027-04-17', 'For students who are the first in their family to attend university.', '2026-11-24 14:51:36'),
(95, 95, 'Urban Planning Grant', 'Young Entrepreneurs Club', 2.80, 'CE', 'no', 'All', 22000, '2027-12-05', 'For CE students working on roads, bridges or water projects.', '2026-11-24 14:51:36'),
(96, 96, 'Environment Protector Award', 'Helping Hands BD', 3.40, 'All', 'yes', 'All', 20000, '2027-09-11', 'For students who work on tree planting, clean-up or recycling projects.', '2026-11-24 14:51:36'),
(97, 97, 'Education Coding Scholarship', 'Chattogram Business Forum', 3.20, 'CSE', 'no', 'All', 45000, '2027-08-19', 'For CSE students who have built a software project or joined a programming contest.', '2026-11-24 14:51:36'),
(98, 98, 'Bright Electronics Scholarship', 'Digital Bangladesh Trust', 3.60, 'EEE', 'no', 'All', 38000, '2027-10-31', 'Supports EEE students who join robotics or hardware competitions.', '2026-11-24 14:51:36'),
(99, 99, 'Female Student Need Grant', 'Padma Education Trust', 2.60, 'All', 'yes', 'Female', 30000, '2027-06-11', 'Helps female students continue studies despite financial problems.', '2026-11-24 14:51:36'),
(100, 100, 'Volunteer Hero Scholarship', 'Education for All Foundation', 3.30, 'All', 'no', 'All', 13000, '2027-04-10', 'For students with regular volunteer work in the community.', '2026-11-24 14:51:36'),
(101, 101, 'Helping Hand Tuition Fund', 'Karnaphuli Alumni Association', 2.70, 'All', 'yes', 'All', 20000, '2027-06-20', 'For hardworking students who may leave studies because of money problems.', '2026-11-24 14:51:36'),
(102, 102, 'Digital Engineering Merit Award', 'Rupsha Industries Welfare Fund', 3.60, 'CSE;EEE;CE', 'no', 'All', 29000, '2027-09-08', 'For engineering students with strong CGPA and a good project record.', '2026-11-24 14:51:36'),
(103, 103, 'Coastal Merit Scholarship', 'Bengal Future Fund', 3.40, 'All', 'no', 'All', 29000, '2027-03-14', 'Rewards consistent academic performance.', '2026-11-24 14:51:36'),
(104, 104, 'Music and Arts Scholarship', 'Karnaphuli Alumni Association', 2.60, 'All', 'yes', 'All', 30000, '2027-11-28', 'For students with talent in music, painting or other arts.', '2026-11-24 14:51:36'),
(105, 105, 'Hope Scholarship', 'Education for All Foundation', 2.10, 'All', 'yes', 'All', 24000, '2027-09-23', 'For students from low-income families who need help with tuition.', '2026-11-24 14:51:36'),
(106, 106, 'Meghna Writing Scholarship', 'Chattogram Business Forum', 3.50, 'English', 'no', 'All', 25000, '2027-10-13', 'For English students who want to become teachers or translators.', '2026-11-24 14:51:36'),
(107, 107, 'Bridge and Road Award', 'Civil Builders Association', 3.30, 'CE', 'no', 'All', 26000, '2027-12-05', 'For CE students working on roads, bridges or water projects.', '2026-11-24 14:51:36'),
(108, 108, 'Consistent Performer Award', 'Chattogram Business Forum', 3.60, 'All', 'no', 'All', 43000, '2027-09-20', 'For students with strong CGPA from any department.', '2026-11-24 14:51:36'),
(109, 109, 'Media and Business Award', 'Bright Minds Trust', 3.40, 'BBA;English', 'no', 'All', 16000, '2027-04-08', 'For students who lead a student club or magazine.', '2026-11-24 14:51:36'),
(110, 110, 'Photography and Media Grant', 'Young Entrepreneurs Club', 2.30, 'All', 'yes', 'All', 21000, '2027-08-30', 'For students with strong photography, video or media work.', '2026-11-24 14:51:36'),
(111, 111, 'Software Builders Award', 'Hilltop Alumni Network', 3.40, 'CSE', 'no', 'All', 27000, '2027-05-09', 'For CSE students interested in artificial intelligence, data or web development.', '2026-11-24 14:51:36'),
(112, 112, 'Hackathon Winners Award', 'Rupsha Industries Welfare Fund', 3.30, 'CSE;EEE', 'no', 'All', 33000, '2027-08-28', 'For CSE and EEE students who want to start research or join a lab.', '2026-11-24 14:51:36'),
(113, 113, 'Sundarban Women Leaders Scholarship', 'Padma Education Trust', 3.00, 'All', 'no', 'Female', 33000, '2027-05-03', 'Supports female students who want to build a career in their field.', '2026-11-24 14:51:36'),
(114, 114, 'Rupsha Coding Scholarship', 'Coastal Bank Foundation', 3.00, 'CSE', 'no', 'All', 22000, '2027-05-16', 'For CSE students interested in artificial intelligence, data or web development.', '2026-11-24 14:51:36'),
(115, 115, 'Shonar Need-Based Support', 'Teesta Education Society', 2.40, 'All', 'yes', 'All', 30000, '2027-02-04', 'Partial support for students facing financial difficulty.', '2026-11-24 14:51:36'),
(116, 116, 'Accounting Excellence Award', 'Teesta Education Society', 3.50, 'BBA', 'no', 'All', 18000, '2027-03-15', 'For BBA students with strong results in accounting or finance courses.', '2026-11-24 14:51:36'),
(117, 117, 'Supply Chain Scholarship', 'Shapla Foundation', 3.50, 'BBA', 'no', 'All', 26000, '2027-02-19', 'For BBA students with strong results in accounting or finance courses.', '2026-11-24 14:51:36'),
(118, 118, 'Family Income Support Grant', 'Helping Hands BD', 2.30, 'All', 'yes', 'All', 23000, '2027-04-16', 'For hardworking students who may leave studies because of money problems.', '2026-11-24 14:51:36'),
(119, 119, 'Digital Women Leaders Scholarship', 'Helping Hands BD', 3.10, 'All', 'no', 'Female', 30000, '2027-05-19', 'Supports female students who want to build a career in their field.', '2026-11-24 14:51:36'),
(120, 120, 'Sports Talent Scholarship', 'Padma Education Trust', 2.30, 'All', 'no', 'All', 19000, '2027-07-25', 'For students who play sports for the university or a district team.', '2026-11-24 14:51:36'),
(121, 121, 'Her Future Grant', 'Young Entrepreneurs Club', 3.50, 'All', 'no', 'Female', 25000, '2027-09-09', 'For female students from any department who show strong effort.', '2026-11-24 14:51:36'),
(122, 122, 'Rupsha Merit Scholarship', 'Bright Minds Trust', 3.50, 'All', 'no', 'All', 25000, '2027-06-23', 'For students who improved their CGPA every semester.', '2026-11-24 14:51:36'),
(123, 123, 'Hilltop Coding Scholarship', 'Hilltop Alumni Network', 3.40, 'CSE', 'no', 'All', 36000, '2027-04-16', 'For CSE students who have built a software project or joined a programming contest.', '2026-11-24 14:51:36'),
(124, 124, 'Freedom Fighter Descendant Support', 'Language Society BD', 2.70, 'All', 'yes', 'All', 11000, '2027-08-18', 'For children or grandchildren of freedom fighters.', '2026-11-24 14:51:36'),
(125, 125, 'National Coding Scholarship', 'Tech Foundation BD', 3.50, 'CSE', 'no', 'All', 32000, '2027-06-01', 'For CSE students who have built a software project or joined a programming contest.', '2026-11-24 14:51:36'),
(126, 126, 'Finance Learners Grant', 'Port City Rotary Friends', 3.10, 'BBA', 'no', 'All', 30000, '2027-02-03', 'Supports BBA students who join business case competitions.', '2026-11-24 14:51:36'),
(127, 127, 'Civil Tech Entrepreneur Grant', 'Bayview University', 3.40, 'BBA;CSE', 'no', 'All', 22000, '2027-05-17', 'For BBA and CSE students who want to build a tech startup.', '2026-11-24 14:51:36'),
(128, 128, 'Daughters Tuition Support', 'Digital Bangladesh Trust', 2.70, 'All', 'yes', 'Female', 26000, '2027-08-12', 'Helps female students continue studies despite financial problems.', '2026-11-24 14:51:36'),
(129, 129, 'Hill Tracts Students Scholarship', 'Education for All Foundation', 2.60, 'All', 'yes', 'All', 27000, '2027-08-01', 'For students from the Chattogram Hill Tracts region.', '2026-11-24 14:51:36'),
(130, 130, 'Tuition Help Scholarship', 'Shonar Bangla Trust', 2.70, 'All', 'yes', 'All', 15000, '2027-01-21', 'For hardworking students who may leave studies because of money problems.', '2026-11-24 14:51:36'),
(131, 131, 'Sundarban Engineering Merit Award', 'Bayview University', 3.80, 'CSE;EEE;CE', 'no', 'All', 42000, '2027-02-10', 'For engineering students who want to continue with higher studies.', '2026-11-24 14:51:36'),
(132, 132, 'High Achievers Grant', 'Surma Learning Foundation', 3.90, 'All', 'no', 'All', 23000, '2027-02-19', 'Rewards consistent academic performance.', '2026-11-24 14:51:36'),
(133, 133, 'Problem Solvers Scholarship', 'Green Delta Care Fund', 3.60, 'CSE', 'no', 'All', 21000, '2027-01-30', 'For CSE students who have built a software project or joined a programming contest.', '2026-11-24 14:51:36'),
(134, 134, 'Cultural Excellence Award', 'Meghna Scholars Society', 2.30, 'All', 'no', 'All', 28000, '2027-03-23', 'For students who take part in cultural events such as music, drama or dance.', '2026-11-24 14:51:36'),
(135, 135, 'Helping Civil Engineering Grant', 'Karnaphuli Alumni Association', 2.80, 'CE', 'no', 'All', 31000, '2027-05-02', 'For CE students who want to work on flood and cyclone resilient buildings.', '2026-11-24 14:51:36'),
(136, 136, 'Academic Excellence Award', 'Chattogram Business Forum', 3.70, 'All', 'no', 'All', 33000, '2027-10-02', 'For students who improved their CGPA every semester.', '2026-11-24 14:51:36');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `scholarships`
--
ALTER TABLE `scholarships`
  ADD PRIMARY KEY (`id`),
  ADD KEY `min_cgpa` (`min_cgpa`),
  ADD KEY `deadline` (`deadline`),
  ADD KEY `amount_bdt` (`amount_bdt`),
  ADD KEY `gender` (`gender`),
  ADD KEY `need_based` (`need_based`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `scholarships`
--
ALTER TABLE `scholarships`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=137;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
