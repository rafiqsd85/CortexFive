# ScholarSearch

ScholarSearch is a PHP and MariaDB scholarship finder with a student dashboard, account sign-in, bookmarks, scholarship comparison, an eligibility gap analyzer, and a local scholarship assistant.

## Quick setup with XAMPP

1. Extract this folder into `C:\xampp\htdocs\ScholarSearch`.
2. Start **Apache** and **MySQL** in XAMPP.
3. Open <http://localhost/ScholarSearch/>. On first run, the app creates `scholarship_db`, imports the supplied `database/scholarship_db.sql`, creates the account/bookmark tables, and seeds the demo students.
4. Click **Sign in**.

The database account must be allowed to create a database and tables. If your MySQL account does not have those permissions, create `scholarship_db` in phpMyAdmin and import `database/scholarship_db.sql`; the app then initializes the account and bookmark tables automatically. `database/02_accounts_and_bookmarks.sql` and `database/seed_demo_accounts.php` are included for manual setup if you prefer.

If you are using the included PHP server, start MySQL in XAMPP, double-click **Start Site.bat**, then open <http://localhost:8080/>.

## Demo accounts

| Student | Username | Password |
|---|---|---|
| Amina Rahman | `student` | `student123` |
| Nadia Islam | `student2` | `student2123` |

The login screen has tap-to-fill demo account cards. Successful sign-in always opens the **Student Dashboard**. Demo passwords are stored with PHP's `password_hash()` and inserted only if the username is not already present.

## Student sign-up and password recovery

Select **Create a student account** on the sign-in page to make a database-backed student account. A new account can sign in immediately with its username or email address. Passwords must contain at least 10 characters.

The **Forgot password?** flow uses single-use, hashed reset tokens that expire after 60 minutes. For email delivery, set `SS_APP_URL` to the full site root (for example `https://example.com/ScholarSearch`) and `SS_MAIL_FROM` to a sender address, then configure PHP's `mail()` transport with your hosting provider. On `localhost`, a development reset link appears if email delivery is unavailable. For any non-local development host, set `SS_APP_ENV=development` and `SS_SHOW_RESET_LINK=true`; never enable that option in production. Production deployments should set `SS_APP_ENV=production` and a trusted `SS_APP_URL`.

## Database connection

Defaults match a local XAMPP install: host `127.0.0.1`, database `scholarship_db`, user `root`, blank password. Set these environment variables before launching the PHP server if your local MySQL settings differ:

| Variable | Default |
|---|---|
| `SS_DB_HOST` | `127.0.0.1` |
| `SS_DB_NAME` | `scholarship_db` |
| `SS_DB_USER` | `root` |
| `SS_DB_PASSWORD` | blank |

The home page and finder load scholarship records from MariaDB. User accounts and bookmarks are stored in the database. Each student's CGPA and profile preferences stay in that student's browser storage, separated by account. Compare selections are also kept per account in browser storage.

## Student workspace

- **Dashboard:** overview of matches and quick access to the student tools.
- **Bookmarks:** save awards to a personal shortlist.
- **Compare:** choose up to three scholarships and compare requirements side by side.
- **Eligibility gap analyzer:** see CGPA distance and other unmet criteria for scholarships.
- **ScholarSearch assistant:** AI-powered chat (OpenRouter / Perplexity) grounded in the live scholarship catalogue and the student’s profile. Falls back to a local rule-based answer if the AI service is unreachable.
- English/Bangla and Light/Dark/Night preferences persist in the browser.
- Footer credits **CortexFive** with the team logo.

## AI assistant (OpenRouter)

The assistant calls OpenRouter from a server-side proxy (`api/chat.php`) so the API key never appears in the browser.

Defaults live in `includes/config.php`. Prefer environment variables in production:

| Variable | Default |
|---|---|
| `OPENROUTER_API_KEY` | (set in config for local demos) |
| `OPENROUTER_MODEL` | `openrouter/free` |

The proxy sends a short system prompt plus a compact snapshot of scholarships and the student’s CGPA / department / need-based flag so answers stay relevant and grounded.

## Run without XAMPP

```bash
php -S localhost:8080 router.php
```

Configure the database environment variables above before starting PHP. `data/scholarships.json` is retained for reference; the live finder reads from MySQL.

These demonstration credentials are intended for local use. Change them (and the OpenRouter key) before exposing the site publicly.
