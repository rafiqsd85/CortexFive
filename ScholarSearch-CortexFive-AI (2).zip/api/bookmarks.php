<?php
declare(strict_types=1);
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/db.php';
header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store');
$user = current_user();
if (!$user) { http_response_code(401); echo json_encode(['error' => 'Sign in to use bookmarks.']); exit; }
try {
    $pdo = db();
    if ($_SERVER['REQUEST_METHOD'] === 'GET') {
        $stmt = $pdo->prepare('SELECT scholarship_id FROM bookmarks WHERE user_id = ? ORDER BY created_at DESC');
        $stmt->execute([(int)$user['id']]);
        echo json_encode(array_map('intval', $stmt->fetchAll(PDO::FETCH_COLUMN)));
        exit;
    }
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') { http_response_code(405); echo json_encode(['error' => 'Method not allowed.']); exit; }
    $token = $_SERVER['HTTP_X_CSRF_TOKEN'] ?? '';
    if (!verify_csrf($token)) { http_response_code(419); echo json_encode(['error' => 'Refresh the page and try again.']); exit; }
    $payload = json_decode(file_get_contents('php://input') ?: '', true);
    $scholarshipId = (int)($payload['scholarship_id'] ?? 0);
    if ($scholarshipId < 1) { http_response_code(422); echo json_encode(['error' => 'Invalid scholarship.']); exit; }
    $check = $pdo->prepare('SELECT 1 FROM scholarships WHERE id = ?');
    $check->execute([$scholarshipId]);
    if (!$check->fetchColumn()) { http_response_code(404); echo json_encode(['error' => 'Scholarship not found.']); exit; }
    $check = $pdo->prepare('SELECT 1 FROM bookmarks WHERE user_id = ? AND scholarship_id = ?');
    $check->execute([(int)$user['id'], $scholarshipId]);
    if ($check->fetchColumn()) {
        $stmt = $pdo->prepare('DELETE FROM bookmarks WHERE user_id = ? AND scholarship_id = ?');
        $stmt->execute([(int)$user['id'], $scholarshipId]);
        echo json_encode(['saved' => false]);
    } else {
        $stmt = $pdo->prepare('INSERT INTO bookmarks (user_id, scholarship_id) VALUES (?, ?)');
        $stmt->execute([(int)$user['id'], $scholarshipId]);
        echo json_encode(['saved' => true]);
    }
} catch (Throwable $e) {
    http_response_code(503);
    echo json_encode(['error' => 'Bookmark service unavailable. Check the account schema setup.']);
}
