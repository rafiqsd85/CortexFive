<?php
declare(strict_types=1);

require_once __DIR__ . '/../includes/db.php';
$pdo = db();
$accounts = [
    ['student', 'Amina Rahman', 'student', 'student123'],
    ['student2', 'Nadia Islam', 'student', 'student2123'],
];
$stmt = $pdo->prepare('INSERT IGNORE INTO app_users (username, display_name, role, password_hash) VALUES (?, ?, ?, ?)');
foreach ($accounts as [$username, $display, $role, $password]) {
    $stmt->execute([$username, $display, $role, password_hash($password, PASSWORD_DEFAULT)]);
}
echo "Demo accounts ready: student / student123 and student2 / student2123\n";
