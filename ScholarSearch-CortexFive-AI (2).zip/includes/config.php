<?php
declare(strict_types=1);

/**
 * Application configuration.
 * Prefer environment variables in production; these are convenient defaults for local demos.
 *
 * Use a chat/instruction model (not a "decider" model).
 * openrouter/free automatically routes to an available free chat model.
 */
if (!defined('OPENROUTER_API_KEY')) {
    define('OPENROUTER_API_KEY', getenv('OPENROUTER_API_KEY') ?: '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');
}
if (!defined('OPENROUTER_MODEL')) {
    // Auto-routes to a working free chat model. Alternatives:
    // nvidia/nemotron-3.5-lightning:free
    // baidu/ernie-5.5-flash-preview:free
    define('OPENROUTER_MODEL', getenv('OPENROUTER_MODEL') ?: 'openrouter/free');
}
if (!defined('OPENROUTER_BASE_URL')) {
    define('OPENROUTER_BASE_URL', 'https://openrouter.ai/api/v1/chat/completions');
}
